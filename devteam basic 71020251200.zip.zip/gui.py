import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import threading
import queue
import os
import main
import glob2 as glob
import sys

class AgentSystemGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Agent System: Hello World")
        self.root.geometry("600x400")
        
        # Output queues
        self.output_queue = queue.Queue()
        self.console_queue = queue.Queue()  # For console tab
        
        # Flag to control output processing
        self.running = True
        self.execution_thread = None
        
        # Create GUI elements
        self.create_widgets()
        
        # Start output processing
        self.process_output_queue()
        self.process_console_queue()

    def create_widgets(self):
        # Button frame
        button_frame = ttk.Frame(self.root)
        button_frame.pack(pady=5, padx=5, fill=tk.X)
        
        # Run button
        self.run_button = ttk.Button(button_frame, text="Run Agent System", command=self.run_system)
        self.run_button.pack(side=tk.LEFT, padx=5)
        
        # View code button
        self.code_button = ttk.Button(button_frame, text="View Source Code", command=self.view_source_code)
        self.code_button.pack(side=tk.LEFT, padx=5)
        
        # View test results button
        self.test_button = ttk.Button(button_frame, text="View Test Results", command=self.view_test_results)
        self.test_button.pack(side=tk.LEFT, padx=5)
        
        # Tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(pady=5, padx=5, fill=tk.BOTH, expand=True)
        
        # Log tab
        self.log_text = scrolledtext.ScrolledText(self.notebook, height=20, width=70, wrap=tk.WORD)
        self.log_text.config(state='disabled')
        self.notebook.add(self.log_text, text="Log")
        
        # Console tab
        self.console_text = scrolledtext.ScrolledText(self.notebook, height=20, width=70, wrap=tk.WORD, foreground='white', background='black')
        self.console_text.config(state='disabled')
        self.notebook.add(self.console_text, text="Console")
        
        # Enable copying from log_text and console_text
        self.setup_copy_functionality()
        
        # Debug button clicks
        self.run_button.bind("<Button-1>", lambda e: print("Run button clicked"))
        self.code_button.bind("<Button-1>", lambda e: print("View Source Code button clicked"))
        self.test_button.bind("<Button-1>", lambda e: print("View Test Results button clicked"))

    def setup_copy_functionality(self):
        """Enable copying from the log_text and console_text widgets."""
        # Bind Ctrl+C (and Cmd+C on macOS)
        self.log_text.bind("<Control-c>", self.copy_selection)
        self.log_text.bind("<Command-c>", self.copy_selection)  # macOS support
        self.console_text.bind("<Control-c>", self.copy_selection)
        self.console_text.bind("<Command-c>", self.copy_selection)
        
        # Create right-click context menu
        self.context_menu = tk.Menu(self.root, tearoff=0)
        self.context_menu.add_command(label="Copy", command=self.copy_selection)
        
        # Bind right-click
        self.log_text.bind("<Button-3>", self.show_context_menu)  # Button-3 is right-click
        self.console_text.bind("<Button-3>", self.show_context_menu)

    def copy_selection(self, event=None):
        """Copy selected text to clipboard."""
        widget = event.widget if event else self.log_text
        try:
            selected_text = widget.selection_get()
            self.root.clipboard_clear()
            self.root.clipboard_append(selected_text)
            print("Text copied to clipboard")
            return "break"  # Prevent default bindings from interfering
        except tk.TclError:
            print("No text selected to copy")
            return "break"

    def show_context_menu(self, event):
        """Show right-click context menu at cursor position."""
        try:
            # Only show menu if text is selected
            if event.widget.selection_get():
                self.context_menu.post(event.x_root, event.y_root)
        except tk.TclError:
            pass

    def run_system(self):
        """Run main.py in a separate thread."""
        print("Attempting to run system")
        if self.execution_thread and self.execution_thread.is_alive():
            messagebox.showinfo("Info", "System is already running. Please wait.")
            return
        
        self.run_button.config(state='disabled')
        self.log_text.config(state='normal')
        self.log_text.delete(1.0, tk.END)
        self.log_text.insert(tk.END, "Starting agent system...\n")
        self.log_text.config(state='disabled')
        self.console_text.config(state='normal')
        self.console_text.delete(1.0, tk.END)
        self.console_text.insert(tk.END, "Console ready.\n")
        self.console_text.config(state='disabled')
        
        # Clear previous outputs
        project_dir = os.path.join(os.getcwd(), "project")
        for folder in ["comms", "src", "tests"]:
            folder_path = os.path.join(project_dir, folder)
            if os.path.exists(folder_path):
                for file in glob.glob(os.path.join(folder_path, "*")):
                    try:
                        os.remove(file)
                    except OSError as e:
                        print(f"Error clearing file {file}: {e}")
        
        # Run main.py in a thread
        self.execution_thread = threading.Thread(target=self.execute_main)
        self.execution_thread.daemon = True
        self.execution_thread.start()

    def execute_main(self):
        """Execute main.py with output redirection."""
        try:
            main.main(self.output_queue, self.console_queue)
        except Exception as e:
            self.output_queue.put(f"Error: {str(e)}\n")
            print(f"Execution error: {e}", file=sys.stderr)
        finally:
            self.output_queue.put("--- Execution complete ---\n")
            self.root.after(0, lambda: self.run_button.config(state='normal'))

    def process_output_queue(self):
        """Process output queue and update log display."""
        if not self.running:
            return
        try:
            while True:
                message = self.output_queue.get_nowait()
                self.log_text.config(state='normal')
                self.log_text.insert(tk.END, message)
                self.log_text.see(tk.END)
                self.log_text.config(state='disabled')
        except queue.Empty:
            pass
        self.root.after(200, self.process_output_queue)

    def process_console_queue(self):
        """Process console queue and update console display."""
        if not self.running:
            return
        try:
            while True:
                message = self.console_queue.get_nowait()
                self.console_text.config(state='normal')
                self.console_text.insert(tk.END, message)
                self.console_text.see(tk.END)
                self.console_text.config(state='disabled')
        except queue.Empty:
            pass
        self.root.after(200, self.process_console_queue)

    def view_source_code(self):
        """Display generated source code in a new window."""
        print("Viewing source code")
        src_dir = os.path.join(os.getcwd(), "project", "src")
        if not os.path.exists(src_dir):
            messagebox.showinfo("Info", "No source code generated yet.")
            return
        
        code_window = tk.Toplevel(self.root)
        code_window.title("Source Code")
        code_window.geometry("400x300")
        
        text_area = scrolledtext.ScrolledText(code_window, height=15, width=50, wrap=tk.WORD)
        text_area.pack(pady=5, padx=5, fill=tk.BOTH, expand=True)
        
        for file in glob.glob(os.path.join(src_dir, "*.py")):
            try:
                with open(file, "r") as f:
                    text_area.insert(tk.END, f"--- {os.path.basename(file)} ---\n")
                    text_area.insert(tk.END, f.read() + "\n\n")
            except OSError as e:
                text_area.insert(tk.END, f"Error reading {file}: {e}\n")
        
        text_area.config(state='disabled')

    def view_test_results(self):
        """Display test results in a new window."""
        print("Viewing test results")
        result_file = os.path.join(os.getcwd(), "project", "tests", "test_result.txt")
        if not os.path.exists(result_file):
            messagebox.showinfo("Info", "No test results available yet.")
            return
        
        result_window = tk.Toplevel(self.root)
        result_window.title("Test Results")
        result_window.geometry("400x200")
        
        text_area = scrolledtext.ScrolledText(result_window, height=10, width=50, wrap=tk.WORD)
        text_area.pack(pady=5, padx=5, fill=tk.BOTH, expand=True)
        
        try:
            with open(result_file, "r") as f:
                text_area.insert(tk.END, f.read())
        except OSError as e:
            text_area.insert(tk.END, f"Error reading {result_file}: {e}\n")
        
        text_area.config(state='disabled')

    def destroy(self):
        """Clean up on window close."""
        self.running = False
        if self.execution_thread and self.execution_thread.is_alive():
            print("Waiting for execution thread to finish")
        self.root.destroy()

def run_gui():
    root = tk.Tk()
    app = AgentSystemGUI(root)
    root.protocol("WM_DELETE_WINDOW", app.destroy)
    root.mainloop()

if __name__ == "__main__":
    run_gui()
