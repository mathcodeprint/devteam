from .base import BaseAgent
import os
import subprocess

class TestingAgent(BaseAgent):
    def __init__(self, name, role, skills, description, project_dir, timeout=30):
        super().__init__(name, role, skills, description, project_dir, timeout=timeout)
        self.src_dir = os.path.join(project_dir, "src")
        self.test_dir = os.path.join(project_dir, "tests")
        os.makedirs(self.test_dir, exist_ok=True)

    def perform_task(self, task):
        """Generate and run a test script using the local AI model."""
        print(f"{self.name} (Role: {self.role}) testing task: {task['description']} ({self.description})")
        
        # Collect developer code
        code_snippets = []
        for file in os.listdir(self.src_dir):
            if file.endswith(".py"):
                with open(os.path.join(self.src_dir, file), "r") as f:
                    code_snippets.append(f.read())
        
        if not code_snippets:
            print(f"{self.name} found no code to test")
            return
        
        # Get test specification
        test_spec = task.get("test_spec", {})
        combination = test_spec.get("combination", "")
        expected_output = test_spec.get("expected_output", "")
        
        # Generate test script using the model
        prompt = (
            f"You are testing a Python program with the following code:\n\n"
            f"{'-' * 80}\n"
            f"{'-' * 80}\n\n"
            f"The task is: {task['description']}.\n"
        )
        if combination:
            prompt += f"Use this test code: {combination}\n"
        else:
            prompt += "Generate a test script that combines these functions to produce the expected output.\n"
        if expected_output:
            prompt += f"The expected output is: '{expected_output}'.\n"
        prompt += (
            "Provide only the test code to append to the functions (e.g., function calls or print statements), "
            "no explanations or additional comments."
        )
        
        test_code = self.call_local_model(prompt)
        if not test_code:
            print(f"{self.name} failed to generate test script")
            return
        
        # Create test script
        combined_script = "\n".join(code_snippets) + "\n\n# Test execution\n" + test_code.strip()
        test_script_path = os.path.join(self.test_dir, "test_hello_world.py")
        with open(test_script_path, "w") as f:
            f.write(combined_script)
        
        # Run the test script
        try:
            result = subprocess.run(
                ["python", test_script_path],
                capture_output=True,
                text=True,
                check=True
            )
            output = result.stdout.strip()
            print(f"{self.name} test output: {output}")
            
            # Verify output
            if expected_output:
                if output == expected_output:
                    print(f"{self.name} test passed: Output matches '{expected_output}'")
                else:
                    print(f"{self.name} test failed: Expected '{expected_output}', got '{output}'")
            else:
                print(f"{self.name} test completed with output: {output}")
            
            # Save test result
            with open(os.path.join(self.test_dir, "test_result.txt"), "w") as f:
                f.write(f"Test Result by {self.name}\n")
                f.write(f"Output: {output}\n")
                f.write(f"Status: {'Passed' if output == expected_output else 'Failed' if expected_output else 'Completed'}\n")
        
        except subprocess.CalledProcessError as e:
            print(f"{self.name} test failed: Execution error - {e}")
            with open(os.path.join(self.test_dir, "test_result.txt"), "w") as f:
                f.write(f"Test Result by {self.name}\n")
                f.write(f"Error: {e}\n")
                f.write("Status: Failed\n")
